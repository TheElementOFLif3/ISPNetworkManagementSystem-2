package com.example.isp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.util.Callback;

public class Controller {

    @FXML
    private ChoiceBox<String> cbSpeed;
    @FXML
    private ChoiceBox<String> cbBandwidth;
    @FXML
    private ChoiceBox<String> cbDuration;
    @FXML
    private TextField tfFullName;
    @FXML
    private TextField tfAddress;
    @FXML
    private ListView<Model> listView;

    private final ObservableList<Model> customersList = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        cbSpeed.getItems().addAll("2", "5", "10", "20", "50", "100");
        cbBandwidth.getItems().addAll("1", "5", "10", "100", "Flat");
        cbDuration.getItems().addAll("1", "2");

        listView.setItems(customersList);

        listView.setCellFactory(new Callback<ListView<Model>, ListCell<Model>>() {
            @Override
            public ListCell<Model> call(ListView<Model> param) {
                return new ListCell<Model>() {
                    @Override
                    protected void updateItem(Model item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty || item == null) {
                            setText(null);
                        } else {
                            setText("Full Name: " + item.getFullName() + "\nAddress: " + item.getAddress() + "\nSpeed: " + item.getSpeed() + " (mb/s)" + "\nDuration: " + item.getDuration() + " Year/s" + "\nBandwidth: " + item.getBandwidth());
                            setStyle("-fx-padding: 10px;");
                        }
                    }
                };
            }
        });
    }

    @FXML
    private void deleteCustomer() {
        Model selectedCustomer = listView.getSelectionModel().getSelectedItem();
        if (selectedCustomer != null) {
            customersList.remove(selectedCustomer);
        } else {
            showErrorAlert("Please select a customer to delete.");
        }
    }

    @FXML
    private void sell() {
        Model customer = new Model();

        int currentStep = 1; // Current step

        // Check Speed
        if (currentStep == 1) {
            String speedValue = cbSpeed.getValue();
            if (isEmpty(speedValue) || speedValue.equals("Select")) {
                showErrorAlert("Please select Speed.");
                return;
            }
            customer.setSpeed(Integer.parseInt(speedValue));
            currentStep++;
        }

        // Check Bandwidth
        if (currentStep == 2) {
            String bandwidthValue = cbBandwidth.getValue();
            if (isEmpty(bandwidthValue) || bandwidthValue.equals("Select")) {
                showErrorAlert("Please select Bandwidth.");
                return;
            }
            customer.setBandwidth(bandwidthValue);
            currentStep++;
        }

        // Check Duration
        if (currentStep == 3) {
            String durationValue = cbDuration.getValue();
            if (isEmpty(durationValue) || durationValue.equals("Select")) {
                showErrorAlert("Please select Duration.");
                return;
            }
            customer.setDuration(Integer.parseInt(durationValue));
            currentStep++;
        }

        // Check Full Name
        if (currentStep == 4) {
            String fullNameValue = tfFullName.getText();
            if (isEmpty(fullNameValue)) {
                showErrorAlert("Please enter Full Name.");
                return;
            }
            customer.setFullName(fullNameValue);
            currentStep++;
        }

        // Check Address
        if (currentStep == 5) {
            String addressValue = tfAddress.getText();
            if (isEmpty(addressValue)) {
                showErrorAlert("Please enter Address.");
                return;
            }
            customer.setAddress(addressValue);
        }

        if (customer.isValid()) {
            customersList.add(customer);
            resetInputFields();
        } else {
            StringBuilder errMsg = new StringBuilder();
            for (String error : customer.errorsProperty()) {
                errMsg.append(error).append("\n");
            }
            showErrorAlert(errMsg.toString());
        }
    }


    private boolean isEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }


    private void resetInputFields() {
        cbSpeed.setValue(null);
        cbBandwidth.setValue(null);
        cbDuration.setValue(null);
        tfFullName.clear();
        tfAddress.clear();
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}