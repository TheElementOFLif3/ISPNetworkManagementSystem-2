package com.example.isp;

import javafx.beans.property.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Model {

    private final IntegerProperty speed = new SimpleIntegerProperty(this, "speed");
    private final StringProperty bandwidth = new SimpleStringProperty(this, "bandwidth");
    private final IntegerProperty duration = new SimpleIntegerProperty(this, "duration");
    private final IntegerProperty id = new SimpleIntegerProperty(this, "id");
    private final StringProperty fullName = new SimpleStringProperty(this, "fullName");
    private final StringProperty address = new SimpleStringProperty(this, "address");
    private final ListProperty<String> errors = new SimpleListProperty<>(FXCollections.observableArrayList());

    public Model() {
    }

    public int getSpeed() {
        return speed.get();
    }

    public IntegerProperty speedProperty() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed.set(speed);
    }

    public String getBandwidth() {
        return bandwidth.get();
    }

    public StringProperty bandwidthProperty() {
        return bandwidth;
    }

    public void setBandwidth(String bandwidth) {
        this.bandwidth.set(bandwidth);
    }

    public int getDuration() {
        return duration.get();
    }

    public IntegerProperty durationProperty() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration.set(duration);
    }

    public int getId() {
        return id.get();
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getFullName() {
        return fullName.get();
    }

    public StringProperty fullNameProperty() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName.set(fullName);
    }

    public String getAddress() {
        return address.get();
    }

    public StringProperty addressProperty() {
        return address;
    }

    public void setAddress(String address) {
        this.address.set(address);
    }

    public ObservableList<String> getErrors() {
        return errors.get();
    }

    public ListProperty<String> errorsProperty() {
        return errors;
    }

    public void addError(String error) {
        errors.add(error);
    }
    public boolean isValid() {
        errors.clear();
        boolean isValid = true;

        if (fullName.get() == null || fullName.get().isEmpty()) {
            addError("Full name must be entered!");
            isValid = false;
        }
        if (address.get() == null || address.get().isEmpty()) {
            addError("Address must be entered!");
            isValid = false;
        }
        if (bandwidth.get() == null || bandwidth.get().isEmpty()) {
            addError("Bandwidth must be selected!");
            isValid = false;
        }
        if (duration.get() == 0) {
            addError("Contract duration must be specified!");
            isValid = false;
        }
        if (speed.get() == 0) {
            addError("Speed must be selected!");
            isValid = false;
        }

        return isValid;

    }

}
